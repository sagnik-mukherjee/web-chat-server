ERROR_STRING = """<html>
<body>
<h1>Error Page for CS352</h1>
<p>
  You have entered wrong credentials or cookie mismatch took place. Please try again !
<p>
</body>
</html>"""